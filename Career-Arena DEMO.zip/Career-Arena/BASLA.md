# Career Arena — Windows-da lokal sınaq

Paketdə 968 suallıq hazır SQLite bazası var: Azərbaycan dili 262, Riyaziyyat 536, İngilis dili 170.

Arxivi aç. Python və layihənin Vite versiyasını dəstəkləyən Node.js quraşdırılmış olmalıdır. Aşağıdakı əmrləri **Career-Arena** qovluğundan başlat. Əvvəlki önbaxış 5000, 5173, 1025 və ya 8025 portlarını tutursa, həmin prosesi əvvəlcə dayandır.

## 1. Lokal poçt qutusu

Birinci PowerShell terminalında:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt -r scripts\requirements-local-mail.txt
.\.venv\Scripts\python.exe scripts\career_arena_local_mail.py
```

## 2. Flask backend

İkinci terminalda:

```powershell
$env:FLASK_ENV = 'development'
$env:FRONTEND_ORIGIN = 'http://127.0.0.1:5173'
$env:PORT = '5000'
$env:SMTP_HOST = '127.0.0.1'
$env:SMTP_PORT = '1025'
$env:SMTP_FROM = 'noreply@example.com'
$env:SMTP_STARTTLS = 'false'
$env:SMTP_USE_SSL = 'false'
$env:SMTP_USERNAME = ''
$env:SMTP_PASSWORD = ''
cd backend
..\.venv\Scripts\python.exe run.py
```

Hazır baza backend/instance/app.db faylındadır. İlk açılış üçün seed işlətməyə ehtiyac yoxdur.

## 3. React frontend

Üçüncü terminalda:

```powershell
cd frontend
npm.cmd ci
npm.cmd run dev -- --host 127.0.0.1
```

1. [Qeydiyyat səhifəsi](http://127.0.0.1:5173/register) üzərindən hesab yarat.
2. [Lokal poçt qutusunu](http://127.0.0.1:8025/) aç və son məktubdakı 6 rəqəmli kodu götür.
3. Təsdiq səhifəsinə kodu yaz. [Fənlər bölməsindən](http://127.0.0.1:5173/subjects) testə başla.

Bu önbaxışda məktublar lokal poçt qutusunda görünür. Real göndəriş üçün SMTP provayderinin məlumatlarını backend/.env faylında konfiqurasiya et və lokal SMTP mühit dəyişənləri verilməyən terminaldan Flask-ı işə sal. Turnstile üçün frontend/.env-də VITE_TURNSTILE_SITE_KEY, backend/.env-də TURNSTILE_SECRET_KEY təyin et.

Orijinal sual ehtiyat nüsxəsi data/db_careerarena__backup.sql faylındadır. Yeni boş baza quranda backend/migrations miqrasiyalarını tətbiq edib backend/scripts/import_question_dump.py skriptinə həmin faylın yolunu verə bilərsən.

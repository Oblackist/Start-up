import React, { useEffect, useMemo, useState } from 'react';
import type { ScreenType } from '../types';
import type { TestResultItem, TestSubmitResult } from '../types';
import { ProgressRing } from '../components/ProgressRing';
import {
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  Sparkles,
  AlertTriangle,
  RotateCcw,
  ArrowLeft,
} from 'lucide-react';
import { ApiErrorClass, getTest } from '../lib/api';

interface ResultScreenProps {
  onSelectScreen: (screen: ScreenType) => void;
  result?: TestSubmitResult | null;
  attemptId?: number | null;
}

/**
 * Convert a backend TestResultItem into the legacy ResultMistake shape used
 * by the existing accordion UI.
 */
function toAccordionItem(item: TestResultItem, idx: number) {
  const exp = item.explanation;
  return {
    id: item.question_id,
    questionNumber: idx + 1,
    topic: item.topic,
    questionText: item.text,
    studentAnswer: item.user_answer ? `${item.user_answer}` : '—',
    correctAnswer: item.correct_answer,
    aiExplanation: {
      summary: exp?.summary || 'İzah mövcud deyil.',
      steps: exp?.steps || [],
      tip: exp?.rule || exp?.tip || '',
    },
  };
}

/**
 * Result screen wired to the backend:
 *   - prefer the result passed in via props (the just-submitted result)
 * *   - otherwise fetch the result by attempt ID
 *   - empty state if none of the above is available
 */
export const ResultScreen: React.FC<ResultScreenProps> = ({
  onSelectScreen,
  result,
  attemptId,
}) => {
  const [data, setData] = useState<TestSubmitResult | null>(result ?? null);
  const [loading, setLoading] = useState<boolean>(!result && Boolean(attemptId));
  const [error, setError] = useState<string | null>(null);
  const [expandedMistakeId, setExpandedMistakeId] = useState<number | null>(null);

  useEffect(() => {
    let cancelled = false;
    // If we already have a result prop, just sync to it.
    if (result) {
      setData(result);
      setLoading(false);
      return;
    }
    (async () => {
      if (attemptId === undefined || attemptId === null) {
        if (!cancelled) setLoading(false);
        return;
      }
      try {
        const fetched = await getTest(attemptId);
        if (!cancelled) {
          setData(fetched);
          setLoading(false);
        }
      } catch (err) {
        if (!cancelled) {
          setError(
            err instanceof ApiErrorClass
              ? err.message
              : 'Nəticəni yükləmək mümkün olmadı. Bir az sonra yenidən cəhd edin.',
          );
          setLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [result, attemptId]);

  // Build derived stats + accordion items.
  const derived = useMemo(() => {
    if (!data) return null;
    const total = data.total || data.results.length;
    const correct = data.results.filter((r) => r.is_correct).length;
    const wrong = data.results.filter((r) => r.user_answer !== null && !r.is_correct).length;
    const blank = data.results.filter((r) => r.user_answer === null).length;
    const scorePct = total > 0 ? Math.round((correct / total) * 100) : 0;
    // Only the WRONG items feed the accordion.
    const mistakes = data.results
      .filter((r) => !r.is_correct)
      .map((r, i) => toAccordionItem(r, i));
    return { total, correct, wrong, blank, scorePct, mistakes };
  }, [data]);

  // First accordion item open by default.
  useEffect(() => {
    if (derived && derived.mistakes.length > 0) {
      setExpandedMistakeId(derived.mistakes[0].id);
    } else {
      setExpandedMistakeId(null);
    }
  }, [derived]);

  // --- Loading ----------------------------------------------------------
  if (loading) {
    return (
      <div className="w-full min-h-screen bg-canvas dark:bg-canvas-dark text-[#0F172A] dark:text-[#E2E8F0] flex flex-col items-center justify-center px-4 transition-colors">
        <div className="w-10 h-10 border-2 border-brand/30 border-t-brand rounded-full animate-spin" />
        <p className="mt-4 text-sm text-slate-500 dark:text-slate-400 font-medium">
          Nəticə yüklənir…
        </p>
      </div>
    );
  }

  // --- Error ------------------------------------------------------------
  if (error) {
    return (
      <div className="w-full min-h-screen bg-canvas dark:bg-canvas-dark text-[#0F172A] dark:text-[#E2E8F0] flex flex-col transition-colors">
        <header className="sticky top-0 z-30 bg-white/90 dark:bg-[#0B1220]/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
          <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center">
            <button
              type="button"
              onClick={() => onSelectScreen('subjects')}
              className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:text-brand dark:hover:text-blue-400 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" strokeWidth={1.75} />
              <span>Fənlər</span>
            </button>
          </div>
        </header>
        <main className="flex-1 flex items-center justify-center px-4 py-12">
          <div className="max-w-md w-full text-center">
            <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto" />
            <p className="mt-4 text-sm font-semibold text-slate-700 dark:text-slate-200">
              Nəticə tapılmadı
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 break-words">{error}</p>
            <button
              onClick={() => onSelectScreen('dashboard')}
              className="mt-6 h-11 px-5 rounded-[12px] bg-brand hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-sm"
            >
              İnkişaf panelinə keç
            </button>
          </div>
        </main>
      </div>
    );
  }

  // --- Empty ------------------------------------------------------------
  if (!data || !derived) {
    return (
      <div className="w-full min-h-screen bg-canvas dark:bg-canvas-dark text-[#0F172A] dark:text-[#E2E8F0] py-12 px-4 sm:px-6 lg:px-8 transition-colors">
        <div className="max-w-[1440px] mx-auto text-center">
          <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto" />
          <h2 className="mt-4 text-xl font-bold text-navy dark:text-white">Nəticə yoxdur</h2>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Hələ heç bir sınaq təqdim etməmisən. Yeni sınaq verərək başla.
          </p>
          <button
            onClick={() => onSelectScreen('subjects')}
            className="mt-6 h-11 px-5 rounded-[12px] bg-brand hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-sm"
          >
            Fənlərə keç
          </button>
        </div>
      </div>
    );
  }

  const { total, correct, wrong, blank, scorePct, mistakes } = derived;
  const subjectName = data.subject_name ?? 'Bu fənn';

  return (
    <div className="w-full min-h-screen bg-canvas dark:bg-canvas-dark text-[#0F172A] dark:text-[#E2E8F0] py-12 px-4 sm:px-6 lg:px-8 transition-colors">
      <div className="max-w-[1440px] mx-auto space-y-10">
        {/* Title & Context */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
          <div className="min-w-0">
            <div className="text-xs font-semibold text-brand dark:text-blue-400 tracking-wider uppercase mb-1">
              Sınaq İmtahanı Hesabatı
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-navy dark:text-white tracking-tight">
              Nəticə və Təhlil
            </h1>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <button
              onClick={() => onSelectScreen('test')}
              className="h-10 px-4 rounded-[12px] bg-slate-100 dark:bg-surface-dark hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold transition-colors flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Yenidən test ver</span>
            </button>
            <button
              onClick={() => onSelectScreen('dashboard')}
              className="h-10 px-4 rounded-[12px] bg-brand hover:bg-blue-700 text-white text-xs font-semibold transition-colors shadow-sm"
            >
              İnkişaf panelinə keç
            </button>
          </div>
        </div>

        {/* TOP SECTION: Readiness Ring + 4 Stat Cards + Weak Topics Column */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* LEFT 7 COLS: Readiness Ring + 4 Stat Cards */}
          <div className="lg:col-span-7 bg-white dark:bg-surface-dark rounded-[20px] p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-calm space-y-8 min-w-0">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div className="space-y-2 text-center sm:text-left min-w-0">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Ümumi Göstərici
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-navy dark:text-white">
                  Hazırlıq səviyyəsi
                </h2>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-xs break-words">
                  {subjectName} üzrə son sınaqda {total} sualdan {correct} düzgün cavabın oldu.
                </p>
              </div>

              <div className="shrink-0 p-3 bg-slate-50 dark:bg-[#0E172A] rounded-2xl border border-slate-100 dark:border-slate-800">
                <ProgressRing
                  progress={scorePct}
                  size={150}
                  strokeWidth={14}
                  color="#2563EB"
                  trackColor="#E2E8F0"
                  label="Hazırlıq"
                  sublabel={scorePct >= 70 ? 'Yaxşı nəticə' : 'İnkişaf etməli'}
                />
              </div>
            </div>

            {/* Four Stat Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {/* Düzgün */}
              <div className="p-4 rounded-2xl bg-teal-50/60 dark:bg-teal-950/20 border border-teal-100 dark:border-teal-900/40 text-center min-w-0">
                <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-teal-700 dark:text-teal-400 mb-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Düzgün</span>
                </div>
                <div className="text-2xl font-extrabold text-teal-800 dark:text-teal-300 tabular-nums">
                  {correct}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {total > 0 ? Math.round((correct / total) * 100) : 0}% dəqiqlik
                </div>
              </div>

              {/* Səhv */}
              <div className="p-4 rounded-2xl bg-red-50/60 dark:bg-red-950/20 border border-red-100 dark:border-red-900/40 text-center min-w-0">
                <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-red-600 dark:text-red-400 mb-1">
                  <XCircle className="w-4 h-4" />
                  <span>Səhv</span>
                </div>
                <div className="text-2xl font-extrabold text-red-700 dark:text-red-400 tabular-nums">
                  {wrong}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {total > 0 ? Math.round((wrong / total) * 100) : 0}% xəta
                </div>
              </div>

              {/* Boş */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-surface-dark-alt border border-slate-200/80 dark:border-slate-800 text-center min-w-0">
                <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
                  <HelpCircle className="w-4 h-4" />
                  <span>Boş</span>
                </div>
                <div className="text-2xl font-extrabold text-slate-700 dark:text-slate-300 tabular-nums">
                  {blank}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {total > 0 ? Math.round((blank / total) * 100) : 0}% cavabsız
                </div>
              </div>

              {/* Cəmi sual */}
              <div className="p-4 rounded-2xl bg-blue-50/60 dark:bg-blue-950/20 border border-blue-100 dark:border-blue-900/40 text-center min-w-0">
                <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-brand dark:text-blue-400 mb-1">
                  <Clock className="w-4 h-4" />
                  <span>Cəmi</span>
                </div>
                <div className="text-2xl font-extrabold text-brand dark:text-blue-300 tabular-nums">
                  {total}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {data.score} bal
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT 5 COLS: "Zəif mövzular" (derived from wrong answers grouped by topic) */}
          <div className="lg:col-span-5 bg-white dark:bg-surface-dark rounded-[20px] p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-calm space-y-6 min-w-0">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 gap-3">
              <div className="flex items-center gap-2 min-w-0">
                <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
                <h3 className="text-lg font-bold text-navy dark:text-white">Zəif mövzular</h3>
              </div>
              <span className="text-xs text-slate-400 font-medium shrink-0">Bu sınaqda</span>
            </div>

            {mistakes.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-6 text-center">
                Bu sınaqda səhv yoxdur. Əla iş!
              </p>
            ) : (
              <div className="space-y-3">
                {(() => {
                  // Group mistakes by topic for the weak-topics list.
                  const grouped = new Map<string, number>();
                  for (const m of mistakes) {
                    grouped.set(m.topic, (grouped.get(m.topic) || 0) + 1);
                  }
                  return Array.from(grouped.entries()).map(([topic, count]) => (
                    <div
                      key={topic}
                      className="p-4 rounded-xl bg-slate-50 dark:bg-[#0E172A] border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-3 min-w-0"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="text-sm font-bold text-slate-900 dark:text-white break-words">
                            {topic}
                          </span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300">
                            {count} səhv
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => onSelectScreen('practice')}
                        className="text-xs font-bold text-brand dark:text-blue-400 hover:underline flex items-center gap-1 shrink-0"
                      >
                        <span>Məşq et</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ));
                })()}
              </div>
            )}

            {mistakes.length > 0 && (
              <div className="pt-2">
                <button
                  onClick={() => onSelectScreen('practice')}
                  className="w-full h-11 rounded-[12px] bg-brand-soft dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/40 text-brand dark:text-blue-300 text-xs font-bold transition-colors flex items-center justify-center gap-2"
                >
                  <span>Bütün zəif mövzuları məşq et</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* BELOW: "Səhvlərin təhlili" ACCORDION */}
        {mistakes.length > 0 && (
          <div className="bg-white dark:bg-surface-dark rounded-[20px] p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-calm space-y-6 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="min-w-0">
                <h3 className="text-xl font-bold text-navy dark:text-white">
                  Səhvlərin təhlili və aydın izahlar
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Səhv cavab verdiyin sualların addım-addım həlli və qaydaları
                </p>
              </div>

              <div className="flex items-center gap-3 flex-wrap">

                <button
                  onClick={() => onSelectScreen('practice')}
                  className="h-10 px-5 rounded-[12px] bg-brand hover:bg-blue-700 active:scale-[0.98] text-white text-xs font-semibold transition-all shadow-sm flex items-center gap-1.5"
                >
                  <span>Fərdi məşqə keç</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Accordion list */}
            <div className="space-y-4">
              {mistakes.map((m) => {
                const isExpanded = expandedMistakeId === m.id;
                return (
                  <div
                    key={m.id}
                    className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-50/50 dark:bg-[#0E172A]/50 transition-all"
                  >
                    <div
                      onClick={() => setExpandedMistakeId(isExpanded ? null : m.id)}
                      className="p-4 sm:p-5 flex items-center justify-between cursor-pointer hover:bg-slate-100/50 dark:hover:bg-[#14223d]/50 transition-colors gap-3"
                    >
                      <div className="flex items-center gap-3.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 flex items-center justify-center font-bold text-xs shrink-0">
                          #{m.questionNumber}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-bold text-navy dark:text-white">
                              Sual {m.questionNumber}
                            </span>
                            <span className="text-slate-300 dark:text-slate-700">·</span>
                            <span className="text-xs text-slate-500 dark:text-slate-400 break-words">
                              {m.topic}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-1 mt-0.5 break-words">
                            {m.questionText}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 shrink-0">
                        <div className="hidden sm:flex items-center gap-3 text-xs">
                          <span className="text-red-600 dark:text-red-400 font-medium">
                            Sənin: {m.studentAnswer}
                          </span>
                          <span className="text-teal-600 dark:text-teal-400 font-bold">
                            Düzgün: {m.correctAnswer}
                          </span>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5 text-slate-400" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-slate-400" />
                        )}
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="p-4 sm:p-6 pt-2 border-t border-slate-200/80 dark:border-slate-800/80 bg-white dark:bg-surface-dark space-y-6 min-w-0">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="p-3.5 rounded-xl bg-red-50/70 dark:bg-red-950/30 border border-red-200/60 dark:border-red-900/50 min-w-0">
                            <span className="text-[11px] font-bold uppercase tracking-wider text-red-600 dark:text-red-400 block mb-1">
                              Sənin cavabın:
                            </span>
                            <span className="text-base font-bold text-red-700 dark:text-red-300 break-words">
                              {m.studentAnswer} (Səhv)
                            </span>
                          </div>

                          <div className="p-3.5 rounded-xl bg-teal-50/70 dark:bg-teal-950/30 border border-teal-200/60 dark:border-teal-900/50 min-w-0">
                            <span className="text-[11px] font-bold uppercase tracking-wider text-teal-600 dark:text-teal-400 block mb-1">
                              Düzgün cavab:
                            </span>
                            <span className="text-base font-bold text-teal-700 dark:text-teal-300 break-words">
                              {m.correctAnswer} (Doğru)
                            </span>
                          </div>
                        </div>

                        {/* AI Explanation */}
                        <div className="p-4 sm:p-5 rounded-2xl bg-blue-50/50 dark:bg-[#0E172A] border border-blue-100 dark:border-blue-900/40 space-y-4 min-w-0">
                          <div className="flex items-center gap-2 text-xs font-bold text-brand dark:text-blue-400">
                            <Sparkles className="w-4 h-4" />
                            <span>İzah və addım-addım həll yolu</span>
                          </div>

                          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed font-medium break-words">
                            {m.aiExplanation.summary}
                          </p>

                          {m.aiExplanation.steps.length > 0 && (
                            <div className="space-y-2 bg-white dark:bg-surface-dark p-4 rounded-xl border border-blue-100/70 dark:border-slate-800 min-w-0">
                              {m.aiExplanation.steps.map((st, i) => (
                                <div
                                  key={i}
                                  className="text-xs text-slate-700 dark:text-slate-300 font-mono break-words min-w-0"
                                >
                                  {st}
                                </div>
                              ))}
                            </div>
                          )}

                          {m.aiExplanation.tip && (
                            <div className="p-3 rounded-lg bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-900/40 text-xs text-amber-800 dark:text-amber-300 break-words min-w-0">
                              <span className="font-bold mr-1">Qızıl qayda:</span>
                              {m.aiExplanation.tip}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

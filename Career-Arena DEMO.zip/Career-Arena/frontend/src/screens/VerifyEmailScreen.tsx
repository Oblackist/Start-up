import { useState } from 'react';
import { authResendVerification, fetchJson } from '../lib/api';
import { useAuth } from '../lib/auth';
import type { User } from '../types';
import { Field, inputClass } from '../components/FormFields';

export function VerifyEmailScreen({
  initialEmail,
  onVerified,
}: {
  initialEmail: string;
  onVerified: () => void;
}) {
  const { refresh } = useAuth();
  const [email, setEmail] = useState(initialEmail);
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [resending, setResending] = useState(false);
  const [notice, setNotice] = useState('');
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      await fetchJson<{ user: User }>('/auth/verify-otp', {
        method: 'POST',
        body: { email, code },
      });
      await refresh();
      onVerified();
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : 'Təsdiq alınmadı.');
    } finally {
      setBusy(false);
    }
  };
  const resend = async () => {
    if (resending || !email.trim()) return;
    setResending(true);
    setNotice('');
    setError('');
    try {
      await authResendVerification({ email });
      setNotice('Əgər bu ünvanda təsdiqlənməmiş hesab varsa, yeni kod göndərildi.');
    } catch (failure) {
      setError(failure instanceof Error ? failure.message : 'Kod göndərilmədi.');
    } finally {
      setResending(false);
    }
  };
  return (
    <div className="max-w-lg w-full mx-auto px-4 py-10">
      <form
        onSubmit={submit}
        className="bg-surface dark:bg-surface-dark border border-stone-200 dark:border-stone-800 rounded-[20px] p-6 space-y-5"
      >
        <h1 className="text-2xl font-extrabold">E-poçtunu təsdiqlə</h1>
        <p>E-poçtuna göndərilən 6 rəqəmli kodu daxil et.</p>
        {error && <p role="alert">{error}</p>}
        {notice && <p role="status">{notice}</p>}
        <Field label="E-poçt" id="verify-email">
          <input
            id="verify-email"
            type="email"
            required
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className={inputClass(false)}
          />
        </Field>
        <Field label="Təsdiq kodu" id="verify-code">
          <input
            id="verify-code"
            required
            pattern="[0-9]{6}"
            maxLength={6}
            autoComplete="one-time-code"
            inputMode="numeric"
            value={code}
            onChange={(event) => setCode(event.target.value)}
            className={inputClass(false)}
          />
        </Field>
        <button
          disabled={busy}
          className="btn-gold py-3 px-5 rounded-xl font-bold disabled:opacity-50"
        >
          Təsdiqlə
        </button>
        <button
          type="button"
          disabled={busy || resending || !email.trim()}
          onClick={resend}
          className="block text-sm font-semibold text-brand disabled:opacity-50"
        >
          {resending ? 'Göndərilir…' : 'Yeni kod göndər'}
        </button>
      </form>
    </div>
  );
}

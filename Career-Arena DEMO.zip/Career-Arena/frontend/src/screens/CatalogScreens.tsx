import { useCallback, useState } from 'react';
import { ArrowRight, BookOpen, Calculator, Globe } from 'lucide-react';
import { asArray, getSubject, getSubjects } from '../lib/api';
import { Link } from '../lib/navigation';
import { useRequest } from '../hooks/useRequest';

const loadSubjects = () => getSubjects().then(asArray);

export function SubjectsScreen() {
  const { data, error, loading } = useRequest(loadSubjects);
  return (
    <div className="max-w-6xl w-full mx-auto px-4 sm:px-6 py-10 space-y-6">
      <h1 className="text-3xl font-extrabold">Fənlər</h1>
      <p className="text-stone-600 dark:text-stone-300">Sınaq vermək istədiyin fənni seç.</p>
      {loading && <p role="status">Fənlər yüklənir…</p>}
      {error && <p role="alert">{error}</p>}
      {data?.length === 0 && <p>Hazırda fənn yoxdur.</p>}
      <div className="grid gap-5 md:grid-cols-3">
        {data?.map((subject) => {
          const Icon =
            subject.icon_name === 'Calculator'
              ? Calculator
              : subject.icon_name === 'Globe'
                ? Globe
                : BookOpen;
          return (
            <article
              key={subject.id}
              className="bg-surface dark:bg-surface-dark rounded-[20px] border border-stone-200 dark:border-stone-800 shadow-calm p-6 flex flex-col gap-4"
            >
              <Icon className="w-8 h-8 text-brand-fg" />
              <h2 className="text-xl font-bold">{subject.name}</h2>
              <p className="text-sm text-stone-600 dark:text-stone-300 flex-1">
                {subject.short_desc}
              </p>
              <div className="text-sm font-semibold">
                {subject.topic_count} mövzu · {subject.question_count} sual
              </div>
              <Link
                to={'/topics?subject=' + encodeURIComponent(subject.id)}
                className="flex gap-2 items-center font-bold text-brand-fg"
              >
                Mövzuları göstər <ArrowRight className="w-4 h-4" />
              </Link>
            </article>
          );
        })}
      </div>
    </div>
  );
}

export function TopicsScreen({ subjectId }: { subjectId: string }) {
  const load = useCallback(() => getSubject(subjectId), [subjectId]);
  const { data, error, loading } = useRequest(load);
  const examPath = '/exam-info?subject=' + encodeURIComponent(subjectId);
  const hasQuestions = data?.topics.some((topic) => topic.question_count > 0);
  return (
    <div className="max-w-4xl w-full mx-auto px-4 sm:px-6 py-10 space-y-5">
      <h1 className="text-3xl font-extrabold">{data?.name ?? 'Mövzu seçimi'}</h1>
      {loading && <p role="status">Mövzular yüklənir…</p>}
      {error && <p role="alert">{error}</p>}
      {data && !hasQuestions && (
        <p role="status">Bu fənn üçün sınaq sualları hələ əlavə edilməyib.</p>
      )}
      {hasQuestions && (
        <Link to={examPath} className="inline-flex btn-gold py-3 px-5 rounded-xl font-bold">
          Bütün mövzular üzrə sınaq
        </Link>
      )}
      <ul className="space-y-3">
        {data?.topics.map((topic) => (
          <li
            key={topic.id}
            className="bg-surface dark:bg-surface-dark border border-stone-200 dark:border-stone-800 p-4 rounded-xl flex items-center justify-between gap-4"
          >
            <div>
              <div className="font-bold">{topic.name}</div>
              <span className="text-sm text-stone-500">{topic.question_count} sual</span>
            </div>
            {topic.question_count > 0 && (
              <Link
                to={examPath + '&topic=' + encodeURIComponent(topic.id)}
                className="font-semibold text-brand-fg"
              >
                Seç
              </Link>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function ExamInfoScreen({
  subjectId,
  topicId,
  onStart,
}: {
  subjectId: string;
  topicId: string | null;
  onStart: (
    input: { subject_id: string; topic_id?: string; question_count: number },
    subjectName: string,
  ) => Promise<void>;
}) {
  const load = useCallback(() => getSubject(subjectId), [subjectId]);
  const { data, error, loading } = useRequest(load);
  const [count, setCount] = useState<number>();
  const [agreed, setAgreed] = useState(false);
  const [busy, setBusy] = useState(false);
  const [startError, setStartError] = useState('');
  const topic = data?.topics.find((item) => item.id === topicId);
  const maximum = Math.min(
    20,
    topicId
      ? (topic?.question_count ?? 0)
      : (data?.topics.reduce((sum, item) => sum + item.question_count, 0) ?? 0),
  );
  const questionCount = Math.min(count ?? maximum, maximum);
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!data || !agreed || busy || !questionCount) return;
    setBusy(true);
    setStartError('');
    try {
      await onStart(
        { subject_id: subjectId, topic_id: topicId ?? undefined, question_count: questionCount },
        data.name,
      );
    } catch (failure) {
      setStartError(failure instanceof Error ? failure.message : 'Sınaq başlamadı.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="max-w-3xl w-full mx-auto px-4 sm:px-6 py-10 space-y-5">
      <h1 className="text-3xl font-extrabold">İmtahan haqqında məlumat</h1>
      {loading && <p role="status">Sınaq məlumatı yüklənir…</p>}
      {(error || startError) && <p role="alert">{error || startError}</p>}
      {data && maximum === 0 && <p>Bu seçim üçün sınaq sualı yoxdur.</p>}
      {data && maximum > 0 && (
        <form
          onSubmit={submit}
          className="bg-surface dark:bg-surface-dark border border-stone-200 dark:border-stone-800 rounded-[20px] p-6 space-y-5"
        >
          <h2 className="text-xl font-bold">
            {data.name} · {topic?.name ?? 'Bütün mövzular'}
          </h2>
          <label className="flex items-center gap-3 font-semibold">
            Sual sayı
            <select
              value={questionCount}
              onChange={(event) => setCount(Number(event.target.value))}
              className="px-3 py-2 rounded-lg border border-stone-300 dark:border-stone-700 bg-surface dark:bg-surface-dark"
            >
              {Array.from({ length: maximum }, (_, index) => index + 1).map((value) => (
                <option key={value}>{value}</option>
              ))}
            </select>
          </label>
          <p>{(questionCount * 1.5).toLocaleString('az-AZ')} dəqiqə · Hər düzgün cavab 1 bal</p>
          <p>
            Sınağın vaxtı bitəndə cavablar avtomatik göndərilir. İmtahan səhifəsindən üç dəfə
            ayrıldıqda sınaq dayandırılır.
          </p>
          <label className="flex gap-2 items-center">
            <input
              type="checkbox"
              checked={agreed}
              onChange={(event) => setAgreed(event.target.checked)}
            />{' '}
            Qaydalarla tanış oldum.
          </label>
          <button
            type="submit"
            disabled={!agreed || busy}
            className="btn-gold py-3 px-5 rounded-xl font-bold disabled:opacity-50"
          >
            {busy ? 'Başladılır…' : 'İmtahana başla'}
          </button>
        </form>
      )}
    </div>
  );
}

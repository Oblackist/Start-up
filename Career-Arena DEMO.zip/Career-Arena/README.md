# Career Arena · Exam Arena

Azərbaycan dilində buraxılış imtahanına hazırlıq platforması. React/Vite frontend Flask API-si ilə işləyir; SQLite lokal/test, TLS PostgreSQL production verilənlər bazasıdır.

## Windows-da işə salmaq

Arxivi açın. Birinci PowerShell pəncərəsində:

```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe scripts/init_db.py
.\.venv\Scripts\python.exe run.py
```

İkinci PowerShell pəncərəsində layihə qovluğundan:

```powershell
cd frontend
npm.cmd ci
npm.cmd run dev
```

Lokal email axınlarını sınamaq üçün `Copy-Item backend/.env.example backend/.env` işlədin və Mailpit-i başladın: `docker run --rm --name career-arena-mailpit -p 1025:1025 -p 8025:8025 axllent/mailpit`. Kod və reset linkləri Flask terminalına yazılmır; `http://localhost:8025` gələnlər qutusunda görünür. Sonra brauzerdə http://localhost:5173 ünvanını açın. Frontend `/api` sorğularını Flask-ın 5000 portuna yönləndirir. Real yayım üçün SMTP provayderini konfiqurasiya etmək tələb olunur.

## Build və API yoxlaması

- `frontend` qovluğunda `npm.cmd run build` TypeScript-i yoxlayır və `dist` qovluğunu yaradır. Flask işləyərkən `npm.cmd run preview` ilə build-i lokal yoxlamaq olar.
- `backend` qovluğunda `.\.venv\Scripts\python.exe tests/smoke_integration.py` ayrıca yaddaşdaxili bazada qeydiyyat, təsdiq, sınaq, nəticə, profil, inkişaf və reytinq axınını yoxlayır.
- Statik hostda frontend marşrutları üçün `index.html` fallback və eyni origin üzərindən `/api` proxy qurulmalıdır.
- İcra olunan route-lar, giriş/CSRF tələbləri, standart limitlər və məlum API boşluqları üçün [API istinadına](docs/API.md) baxın.

## Sınaq məlumatları

Yayım paketində Azərbaycan dili, Riyaziyyat və İngilis dili üzrə 968 sualdan ibarət SQLite bazası var. Yeni baza quranda `scripts/init_db.py` ilə miqrasiyaları tətbiq et, sonra `scripts/import_question_dump.py` ilə SQL ehtiyat nüsxəsini yüklə. İmtahan sualları seçilən fənn və mövzu üzrə bazadan təsadüfi seçilir.

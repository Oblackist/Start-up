"""Test schemas."""
from __future__ import annotations

from marshmallow import Schema, fields, validate, EXCLUDE


class CreateTestSchema(Schema):
    class Meta:
        unknown = EXCLUDE
        ordered = True

    subject_id = fields.String(required=True, validate=validate.Length(min=1, max=40))
    question_count = fields.Integer(strict=True, validate=validate.Range(min=1, max=20))
    topic_id = fields.String(required=False, validate=validate.Length(min=1, max=40))


class SubmitTestSchema(Schema):
    class Meta:
        unknown = EXCLUDE
        ordered = True

    answers = fields.Dict(
        keys=fields.String(),  # question_id (string in JSON)
        values=fields.String(allow_none=True, validate=validate.Length(max=1)),
        required=True,
    )

    def load(self, *args, **kwargs):  # type: ignore[override]
        data = super().load(*args, **kwargs)
        answers = data.get("answers") or {}
        # Each key must be a positive integer-as-string; value is one uppercase letter
        # or None. We coerce and strip later in the service.
        cleaned: dict[str, str | None] = {}
        for k, v in answers.items():
            try:
                _ = int(k)
            except (TypeError, ValueError):
                raise ValueError("answer keys must be question ids")
            if v is None:
                cleaned[k] = None
                continue
            if not isinstance(v, str) or len(v) == 0:
                raise ValueError("answer values must be a non-empty string")
            # Accept exactly one char OR a longer string starting with the key (e.g. "A) 12")
            # The contract body uses single-letter values. Be strict: take first char only.
            cleaned[k] = v[:1]
        data["answers"] = cleaned
        return data


__all__ = ["CreateTestSchema", "SubmitTestSchema"]

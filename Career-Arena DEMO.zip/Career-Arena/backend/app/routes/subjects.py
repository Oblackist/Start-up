"""Public content routes: /subjects, /subjects/<id>, /subjects/<id>/topics."""
from __future__ import annotations

from flask import Blueprint, jsonify, request
from sqlalchemy import select, func

from ..extensions import db
from ..models.content import Subject, Topic, Question
from ..utils.errors import ApiError, ErrorCode

bp = Blueprint("subjects", __name__)


def _subject_summary(s: Subject, topic_count: int, question_count: int) -> dict:
    return {
        "id": s.id,
        "name": s.name,
        "short_desc": s.short_desc,
        "icon_name": s.icon_name,
        "topic_count": topic_count,
        "question_count": question_count,
    }


@bp.route("/subjects", methods=["GET"])
def list_subjects():
    topics = select(Topic.subject_id, func.count().label("total")).group_by(Topic.subject_id).subquery()
    questions = select(Question.subject_id, func.count().label("total")).group_by(Question.subject_id).subquery()
    rows = db.session.execute(
        select(Subject, topics.c.total, questions.c.total)
        .outerjoin(topics, topics.c.subject_id == Subject.id)
        .outerjoin(questions, questions.c.subject_id == Subject.id)
        .order_by(Subject.id)
    )
    return jsonify([_subject_summary(s, tc or 0, qc or 0) for s, tc, qc in rows]), 200


def _topics(subject_id: str) -> list[dict]:
    counts = select(Question.topic_id, func.count().label("total")).where(
        Question.subject_id == subject_id
    ).group_by(Question.topic_id).subquery()
    rows = db.session.execute(
        select(Topic, counts.c.total).outerjoin(counts, counts.c.topic_id == Topic.id)
        .where(Topic.subject_id == subject_id).order_by(Topic.order, Topic.id)
    )
    return [{"id": topic.id, "name": topic.name, "question_count": count or 0} for topic, count in rows]


@bp.route("/subjects/<subject_id>", methods=["GET"])
def get_subject(subject_id: str):
    s = db.session.get(Subject, subject_id)
    if s is None:
        raise ApiError(404, ErrorCode.NOT_FOUND, "Mövzu tapılmadı")
    return jsonify({
        "id": s.id,
        "name": s.name,
        "short_desc": s.short_desc,
        "icon_name": s.icon_name,
        "topics": _topics(subject_id),
    }), 200


@bp.route("/subjects/<subject_id>/topics", methods=["GET"])
def list_subject_topics(subject_id: str):
    s = db.session.get(Subject, subject_id)
    if s is None:
        raise ApiError(404, ErrorCode.NOT_FOUND, "Mövzu tapılmadı")
    return jsonify(_topics(subject_id)), 200


__all__ = ["bp"]

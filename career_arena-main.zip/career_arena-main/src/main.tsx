import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router';
import App from './App.tsx';
import { ExamProvider } from './context/ExamContext';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <BrowserRouter>
    <ExamProvider>
      <App />
    </ExamProvider>
  </BrowserRouter>,
);
